export default [
  {
    name: "My Profile",
    iconType: "Material",
    iconName: "face-profile",
  },
  {
    name: "My Earnings",
    iconType: "Feather",
    iconName: "settings",
  },
  {
    name: "Reset Pin",
    iconType: "Material",
    iconName: "bookmark-check-outline",
  },
  {
    name: "Account Settings",
    iconType: "FontAwesome5",
    iconName: "user-friends",
  },
  {
    name: "Privacy Policy",
    iconType: "FontAwesome5",
    iconName: "user-friends",
  },
  {
    name: "Contact Us",
    iconType: "FontAwesome5",
    iconName: "user-friends",
  },
  {
    name: "Logout",
    iconType: "FontAwesome5",
    iconName: "user-friends",
  },
];
