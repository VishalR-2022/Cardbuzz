import React, { useState, useEffect } from "react";
import {
  Text,
  StyleSheet,
  SafeAreaView,
  View,
  TouchableOpacity,
  ScrollView,
} from "react-native";
import DateTimePicker from "@react-native-community/datetimepicker"; // Import the date picker component
import { BackButton, Divider, Transactions } from "../components";
import { AndroidSafeArea, COLORS, SIZES } from "../constants/theme";
import { useNavigation } from "@react-navigation/native";
import { Wallet } from "../svg";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";

const History = () => {
  const navigation = useNavigation();
  const [active, setActive] = useState(0);
  const [fromDate, setFromDate] = useState(null);
  const [toDate, setToDate] = useState(null);
  const [isDatePickerVisible, setDatePickerVisible] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date());

  const scrollButtons = ["Today", "Last 7 Days", "Last 30 Days", "Custom"];

  const handleDateConfirm = (selectedDate) => {
    if (!fromDate) {
      setFromDate(selectedDate);
    } else if (!toDate && selectedDate > fromDate) {
      setToDate(selectedDate);
    } else {
      // Show error or reset the selection
      setFromDate(null);
      setToDate(null);
    }
  };

  const fromToButtonText = () => {
    if (fromDate && toDate) {
      return `From ${fromDate.toDateString()} - To ${toDate.toDateString()}`;
    } else if (fromDate) {
      return `From ${fromDate.toDateString()}`;
    } else if (toDate) {
      return `To ${toDate.toDateString()}`;
    }
    return "Custom";
  };

  console.log(fromDate, toDate, isDatePickerVisible);
  const renderScrollButton = () => {
    return (
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        <View style={styles.scrollButtonContainer}>
          {scrollButtons.map((item, index) => (
            <HorizontalButton
              text={item === "Custom" ? fromToButtonText() : item}
              index={index}
            />
          ))}
        </View>
      </ScrollView>
    );
  };

  function renderTop() {
    return <BackButton text="My Earnings" />;
  }

  const HorizontalButton = ({ text, index }) => {
    return (
      <TouchableOpacity
        onPress={() => {
          setActive(index);
          console.log(index == 3);
          if (index == 3) {
            setDatePickerVisible(false);
          }
        }}
        style={{
          ...styles.horizontalButton,
          borderWidth: active === index ? 0 : 1,
          borderRadius: 6,
          backgroundColor: active === index ? COLORS.Primary : COLORS.White,
        }}
      >
        <Text
          style={{
            color: active === index ? COLORS.White : COLORS.TextDark,
            fontSize: 16,
            fontWeight: active === index ? "600" : "500",
          }}
        >
          {text}
        </Text>
      </TouchableOpacity>
    );
  };
  function renderContent() {
    return (
      <View
        style={{
          marginHorizontal: 16,
          backgroundColor: "#f5f5f5",
          marginVertical: 20,
          borderRadius: 8,
        }}
      >
        <View style={styles.searchBar}>
          <View>
            <Wallet strokeColor={true} />
          </View>
          <Text style={styles.contentTitle}>Total Earning</Text>
          <Text style={styles.walletAmount}>₹2,000</Text>
        </View>
      </View>
    );
  }

  return (
    <SafeAreaView
      style={{ ...styles.container, ...AndroidSafeArea.AndroidSafeArea }}
    >
      <KeyboardAwareScrollView
        contentContainerStyle={{
          flexGrow: 1,
          paddingBottom: 8,
        }}
        showsVerticalScrollIndicator={false}
      >
        {renderTop()}
        {renderContent()}
        {renderScrollButton()}
        <Transactions earnings={true} />
      </KeyboardAwareScrollView>
      {isDatePickerVisible && (
        <View>
          <DateTimePicker
            value={toDate || selectedDate}
            mode="date"
            onChange={(event, date) => setToDate(date)}
            testID="dateTimePickerEnd"
            onTouchCancel={() => setDatePickerVisible(false)}
          />
        </View>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    margin: 0,
    flex: 1,
    paddingVertical: 0,
    backgroundColor: "#ffff",
    display: "flex",
  },
  searchBar: {
    display: "flex",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderRadius: SIZES.borderRadius,
    padding: 10,
    backgroundColor: "#f5f5f5",
    gap: 20,
  },
  walletAmount: {
    fontSize: 16,
    color: COLORS.TextDark,
    fontWeight: "700",
  },
  contentTitle: {
    fontSize: 16,
    color: COLORS.TextDark,
    fontWeight: "500",
    flex: 1,
    justifyContent: "flex-start",
  },
  buttonContainer: {
    alignItems: "center",
    marginTop: 50,
    paddingBottom: 20,
    justifyContent: "flex-end",
    marginHorizontal: 16,
  },
  uploadContainer: {
    elevation: 2,
    height: 80,
    width: 80,
    backgroundColor: "#efefef",
    borderRadius: 999,
    overflow: "hidden",
  },
  edit: {
    backgroundColor: "#717171",
    position: "absolute",
    bottom: 0,
    right: 0,
    width: 24,
    height: 24,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    zIndex: 2,
    borderRadius: 68,
  },
  userName: {
    fontSize: 24,
    fontWeight: "600",
    lineHeight: 22,
    color: COLORS.TextDark,
  },
  contactInfo: {
    fontSize: 12,
    fontWeight: "600",
    lineHeight: 22,
    color: COLORS.TextDark,
  },
  horizontalButton: {
    paddingHorizontal: 20,
    paddingVertical: 8,
    borderColor: "#EDEDED",
  },
  scrollButtonContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginHorizontal: 16,
  },
});

export default History;
